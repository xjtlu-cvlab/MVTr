import torch, os
import numpy as np
from argparse import ArgumentParser
from matplotlib import cm
from PIL import Image
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader 
from tqdm import tqdm


def get_worldcoord_from_worldgrid(worldgrid):
    # datasets default unit: centimeter & origin: (-300,-900)
    grid_x, grid_y = worldgrid
    coord_x = grid_x / 40
    coord_y = grid_y / 40
    return np.array([coord_x, coord_y])


def project(corner_3d, calib):
    corner_2d = np.dot(calib, corner_3d.T)
    corner_2d[0, :] = corner_2d[0, :] / corner_2d[2, :]
    corner_2d[1, :] = corner_2d[1, :] / corner_2d[2, :]
    corner_2d = np.array(corner_2d, dtype=np.int)
    return corner_2d[0:2, :].T

def to_numpy(data):
    if isinstance(data, np.ndarray):
        return data
    elif isinstance(data, torch.Tensor):
        return data.detach().cpu().numpy()
    else:
        return np.array(data)

def construct_location(objects):
    locaitons = list()
    for i, obj in enumerate(objects):
        tmp = np.zeros(shape=(1, 3))
        tmp[:, 0] = i
        tmp[:, :2] = to_numpy(obj.location)[:2]
        locaitons.append(tmp)
    return np.concatenate(locaitons, axis=0)

class FormatAPAOSData():
    def __init__(self, save_dir, mode='pred') -> None:
        assert mode in ['pred', 'gt'], 'mode error'
        self.mode = mode
        self.save_dir = save_dir
        self.data = None

    def add_item(self, batch, id):
        id = np.array(id).reshape(-1)
        # construct stored data with format: frame_id, x, y, z, l, w, h, rotation, conf
        for obj in batch:
            dimension = to_numpy(obj.dimension)[::-1]
            location = to_numpy(obj.location)
            rotation = to_numpy(obj.rotation).reshape(-1)
            if self.mode == 'pred':
                conf = to_numpy(obj.conf).reshape(-1)
            if self.data is None:
                if self.mode == 'pred':
                    self.data = np.concatenate([id, location, dimension, rotation, conf], axis=0).reshape(1, -1)
                else:
                    self.data = np.concatenate([id, location, dimension, rotation], axis=0).reshape(1, -1)
            else:
                if self.mode == 'pred':
                    tmp = np.concatenate([id, location, dimension, rotation, conf], axis=0).reshape(1, -1)
                    self.data = np.vstack([self.data, tmp])
                else:
                    tmp = np.concatenate([id, location, dimension, rotation], axis=0).reshape(1, -1)
                    self.data = np.vstack([self.data, tmp])
    def save(self):
        if not os.path.exists(os.path.dirname(self.save_dir)):
            os.mkdir(os.path.dirname(self.save_dir))
        np.savetxt(self.save_dir, self.data)           
    
    def exist(self):
        return os.path.exists(self.save_dir)

class FormatPRData():
    def __init__(self, save_dir) -> None:
        self.data = None
        self.save_dir = save_dir

    def add_item(self, batch, id):
        location = construct_location(batch)
        if self.data is None:
            self.data = np.concatenate([ np.ones((location.shape[0], 1))*id,  location], axis=1)
        else:
            tmp = np.concatenate([ np.ones((location.shape[0], 1))*id,  location], axis=1)
            self.data = np.concatenate([self.data, tmp], axis=0)
    def save(self):
        if not os.path.exists(os.path.dirname(self.save_dir)): 
            os.mkdir(os.path.dirname(self.save_dir))
        np.savetxt(self.save_dir, self.data)
    
    def exist(self):
        return os.path.exists(self.save_dir)

def visualize_image(image):
    # image format: (3, H, W) value range: (0, 1)
    # reverse tensor to RGB image
    image = image.detach().cpu().numpy()#.transpose(1, 2, 0)
    image = (image * 255).astype(np.uint8)
    return image

def my_3D(image, calibs, objects, preds, args):

    fig = plt.figure(num='bbox', figsize=(10, 8))
    fig.clear()

    ax1 = plt.subplot(211)
    ax2 = plt.subplot(212)

    # _format_bottom(image, calibs, objects, args, ax=ax1)
    _format_bboxes(image, calibs, objects, ax=ax1)
    ax1.set_title('GroundTruth')

    _format_bboxes(image, calibs, preds, ax=ax2)
    ax2.set_title('Prediction')

    return fig

def _format_bboxes(image, calib, objects, cmap=None, ax=None):
    height = 180
    if ax is None:
        fig, ax = plt.subplots()
    ax.clear()

    # Visualize image
    ax.imshow(visualize_image(image).transpose(1, 2, 0))
    extents = ax.axis()

    # Visualize objects
    if cmap is None:
        cmap = cm.get_cmap('tab20', len(objects))  


    for i, obj in enumerate(objects):
        obj.location[2] = 0
        headcoord = Wildtrack.get_worldcoord_from_worldgrid(to_numpy(obj.location))
        ax = draw_3DBBox(ax, to_numpy([height, height*0.35, height*0.35]), to_numpy(headcoord), to_numpy(calib), cmap(i), 1)

    ax.axis(extents)
    ax.axis(False)
    ax.grid(False)
    return ax

def rotz(t):
    """ Rotation about z-axis """
    c = np.cos(t)
    s = np.sin(t)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])

def corners8_to_rect4(corners8):
    xmin = np.min(corners8[:, 0])
    ymin = np.min(corners8[:, 1])
    xmax = np.max(corners8[:, 0])
    ymax = np.max(corners8[:, 1])
    return [xmin, ymin, xmax, ymax]


def draw_3DBBox(ax, dimension, location, calib, edgecolor=(0, 1, 0), linewidth=1):
    location[:2] = get_worldcoord_from_worldgrid(location[:2])
    print(location)
    corners = compute_3d_bbox(dimension, location, calib)
    [xmin, ymin, xmax, ymax] = corners8_to_rect4(corners)
    if len(corners) != 8:
        return ax
    assert corners.shape[1] == 2, 'corners` shape should be [8, 2]'
    for k in range(0, 4):
        i, j = k, (k + 1) % 4
        ax.plot((corners[i, 0], corners[j, 0]), (corners[i, 1], corners[j, 1]), color=edgecolor, linewidth=linewidth)
        i, j = k + 4, (k + 1) % 4 + 4
        ax.plot((corners[i, 0], corners[j, 0]), (corners[i, 1], corners[j, 1]), color=edgecolor, linewidth=linewidth)
        i, j = k, k + 4
        ax.plot((corners[i, 0], corners[j, 0]), (corners[i, 1], corners[j, 1]), color=edgecolor, linewidth=linewidth)
    width = xmax - xmin 
    height = ymax - ymin
    rect = plt.Rectangle([xmin, ymin], width, height, color=(1, 0, 0), linewidth=1.5, fill=False)
    ax.add_patch(rect)
    return ax


def compute_3d_bbox(dimension, location, calib):
    h, w, l = dimension[0], dimension[1], dimension[2]
    x = [-l / 2, l / 2, l / 2, -l / 2, -l / 2, l / 2, l / 2, -l / 2]
    y = [-w / 2, -w / 2, w / 2, w / 2, -w / 2, -w / 2, w / 2, w / 2]
    z = [0, 0, 0, 0, h, h, h, h]
    # NOTICE! rotation: -np.pi ~ np.pi ! instead of -180 ~ 180
    corner_3d = np.vstack([x, y, z])
    bottom_center = np.tile(location, (corner_3d.shape[1], 1)).T
    corner_3d = corner_3d + bottom_center
    corner_3d_homo = np.vstack([corner_3d, np.ones((1, corner_3d.shape[1]))])
    corner_2d = project(corner_3d_homo.T, calib)
    print(corner_2d)
    return corner_2d

def _format_bottom(image, calib, objects, args, ax=None, height=None):
    if ax is None:
        fig, ax = plt.subplots()
    ax.clear()

    # Visualize image
    image = Image.fromarray(visualize_image(image).transpose(1, 2, 0))
    image = image.resize(args.image_size[::-1])
    ax.imshow(image)
    extents = ax.axis()
    ax.axis(extents)
    ax.axis(False)
    ax.grid(False)

    # Construct homography coord of bottom
    bottom = list()
    head = list()
    for obj in objects:
        worldcoord = np.zeros((3), dtype=np.float32)
        if args.data == MultiviewX.__name__:
            worldcoord[:2] = MultiviewX.get_worldcoord_from_worldgrid(to_numpy(obj.location[:2]))
        elif args.data == Wildtrack.__name__:
            worldcoord[:2] = Wildtrack.get_worldcoord_from_worldgrid(to_numpy(obj.location[:2]))
            if height is not None:
                obj.location[2] = height
                headcoord = Wildtrack.get_worldcoord_from_worldgrid(to_numpy(obj.location))
        else:
            raise ValueError('Unknow dataset. Expect {} and {}, but got{}.'\
                            .format(MultiviewX.__name__, 
                                    Wildtrack.__name__,
                                    args.data
                                    ))
        bottom.append(worldcoord)
        if height is not None:
            head.append(headcoord)

    bottom = np.array(bottom).reshape(-1, 3)
    bottom3d = np.concatenate([bottom, np.ones((bottom.shape[0], 1))], axis=1)
    bottom2d = project(bottom3d, to_numpy(calib))
    # Visualize bottom center 
    ax.scatter(bottom2d[:, 0], bottom2d[:, 1], s=5, c='red')

    if height is not None:
        head = np.array(head).reshape(-1, 3)
        head3d = np.concatenate([head, np.ones((head.shape[0], 1))], axis=1)
        head2d = project(head3d, to_numpy(calib))
        # Visualize bottom center 
        ax.scatter(head2d[:, 0], head2d[:, 1], s=5, c='yellow')
    return ax
    