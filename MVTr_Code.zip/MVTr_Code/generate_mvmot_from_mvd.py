import json
import os

import pandas as pd

from multiview_detector.datasets import frameDataset, Wildtrack, MultiviewX, MVPerception


def extract_info_from_json(json_file, fun, datasetname):
    with open(json_file, 'r') as f:
        data = json.load(f)
        views_dataframes = {}

    frame = int(os.path.basename(json_file).split('.')[0])

    for person in data:
        person_id = person['personID']
        if fun is not None:
            if datasetname == 'Wildtrack':
                y, x = fun(person['positionID'])
            elif datasetname == 'Multiviewx' or datasetname == 'MVPerception':
                x, y = fun(person['positionID'])
            row = {'Frame': frame, 'PersonID': person_id, 'x': int(x), 'y': int(y)}
            view_num = 0
            if view_num not in views_dataframes:
                views_dataframes[view_num] = pd.DataFrame([row])
            else:
                views_dataframes[view_num] = views_dataframes[view_num].append(row, ignore_index=True)
        else:
            for view in person['views']:
                view_num = view['viewNum']
                if view['xmax'] == -1 or view['xmin'] == -1 or view['ymax'] == -1 or view['ymin'] == -1:
                    pass
                else:
                    w = view['xmax'] - view['xmin']
                    h = view['ymax'] - view['ymin']

                    if datasetname == 'Wildtrack':
                        row = {'Frame': frame, 'PersonID': person_id, 'y': view['ymin'], 'x': view['xmin'], 'w': w,
                               'h': h, 'oc': 0, 'class': -1, '1': -1, '0': -1}
                    elif datasetname == 'Multiviewx' or datasetname == 'MVPerception':
                        row = {'Frame': frame, 'PersonID': person_id, 'x': view['xmin'], 'y': view['ymin'], 'w': w,
                               'h': h, 'oc': 0, 'class': -1, '1': -1, '0': -1}

                    if view_num not in views_dataframes:
                        views_dataframes[view_num] = pd.DataFrame([row])
                    else:
                        views_dataframes[view_num] = views_dataframes[view_num].append(row, ignore_index=True)
    return views_dataframes


def ground_plane(datasetname='wildtrack'):
    if datasetname == 'Wildtrack':
        dataset = frameDataset(Wildtrack(os.path.expanduser(f'Data/{datasetname}')), False, )
    elif datasetname == 'Multiviewx':
        dataset = frameDataset(MultiviewX(os.path.expanduser(f'Data/{datasetname}')), False, )
    elif datasetname == 'MVPerception':
        dataset = frameDataset(MVPerception(os.path.expanduser(f'Data/{datasetname}')), False, )
    get_worldgrid = dataset.base.get_worldgrid_from_pos

    dir_path = f'Data/{datasetname}/annotations_positions'
    save_path = f'Data/{datasetname}/mot_gt'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    all_views_dataframes = {}

    for file in os.listdir(dir_path):
        if file.endswith('.json'):
            file_path = os.path.join(dir_path, file)
        views_dataframes = extract_info_from_json(file_path, get_worldgrid, datasetname)

        for view_num, dataframe in views_dataframes.items():
            if view_num in all_views_dataframes:
                all_views_dataframes[view_num] = pd.concat([all_views_dataframes[view_num], dataframe])
            else:
                all_views_dataframes[view_num] = dataframe

        with open(os.path.join(save_path, 'gt.txt'), 'w') as file:
            for view_num, dataframe in all_views_dataframes.items():
                file.write(dataframe.to_csv(sep=' ', index=False, header=False))


if __name__ == '__main__':
    ground_plane('wildtrack')
