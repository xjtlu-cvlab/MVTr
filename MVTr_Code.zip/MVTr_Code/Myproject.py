import argparse
import os
import sys
import random

import numpy as np
import torch
import torch.nn.functional as F
import tqdm
from datetime import datetime
from matplotlib import pyplot as plt
from torch import optim
from torch.cuda.amp import GradScaler
from torch.utils.data import DataLoader

from MVtr import MVtr
from multiview_detector.utils.draw_curve import draw_curve
from trainer import PerspectiveTrainer

os.environ['OMP_NUM_THREADS'] = '1'

from torch import nn
from multiview_detector.datasets import *
from multiview_detector.utils.str2bool import str2bool
from multiview_detector.utils.projection import get_worldcoord_from_imgcoord_mat, project_2d_points
from mvmot_evaluate import main as eval


class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "w")

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)

    def flush(self):
        pass


def output_head(in_dim, feat_dim, out_dim):
    if feat_dim:
        fc = nn.Sequential(nn.Conv2d(in_dim, feat_dim, 3, padding=1), nn.ReLU(),
                           nn.Conv2d(feat_dim, out_dim, 1))
    else:
        fc = nn.Sequential(nn.Conv2d(in_dim, out_dim, 1))
    return fc


def create_reference_map(dataset, n_points=4, downsample=2, visualize=False):
    H, W = dataset.Rworld_shape  # H,W; N_row,N_col
    H, W = H // downsample, W // downsample
    ref_y, ref_x = torch.meshgrid(torch.linspace(0.5, H - 0.5, H, dtype=torch.float32),
                                  torch.linspace(0.5, W - 0.5, W, dtype=torch.float32))
    ref = torch.stack((ref_x, ref_y), -1).reshape([-1, 2])
    if n_points == 4:
        zs = [0, 0, 0, 0]
    elif n_points == 8:
        zs = [-0.4, -0.2, 0, 0, 0.2, 0.4, 1, 1.8]
    else:
        raise Exception
    ref_maps = torch.zeros([H * W, dataset.num_cam, n_points, 2])
    world_zoom_mat = np.diag([dataset.world_reduce * downsample, dataset.world_reduce * downsample, 1])
    Rworldgrid_from_worldcoord_mat = np.linalg.inv(
        dataset.base.worldcoord_from_worldgrid_mat @ world_zoom_mat @ dataset.base.world_indexing_from_xy_mat)
    for cam in range(dataset.num_cam):
        mat_0 = Rworldgrid_from_worldcoord_mat @ get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                                  dataset.base.extrinsic_matrices[cam])
        for i, z in enumerate(zs):
            mat_z = Rworldgrid_from_worldcoord_mat @ get_worldcoord_from_imgcoord_mat(
                dataset.base.intrinsic_matrices[cam],
                dataset.base.extrinsic_matrices[cam],
                z / dataset.base.worldcoord_unit)
            img_pts = project_2d_points(np.linalg.inv(mat_z), ref)
            ref_maps[:, cam, i, :] = torch.from_numpy(project_2d_points(mat_0, img_pts))
        pass
        if visualize:
            fig, ax = plt.subplots()
            field_x = (ref_maps[:, cam, 3, 0] - ref_maps[:, cam, 1, 0]).reshape([H, W])
            field_y = (ref_maps[:, cam, 3, 1] - ref_maps[:, cam, 1, 1]).reshape([H, W])
            ax.streamplot(ref_x.numpy(), ref_y.numpy(), field_x.numpy(), field_y.numpy())
            ax.set_aspect('equal', 'box')
            ax.invert_yaxis()
            plt.show()

    ref_maps[:, :, :, 0] /= W
    ref_maps[:, :, :, 1] /= H
    return ref_maps


class MLP(nn.Module):
    """ Very simple multi-layer perceptron (also called FFN)"""

    def __init__(self, input_dim, hidden_dim, output_dim, num_layers):
        super().__init__()
        self.num_layers = num_layers
        h = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(
            nn.Linear(n, k)
            for n, k in zip([input_dim] + h, h + [output_dim]))

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < self.num_layers - 1 else layer(x)
        return x


def main(args):
    date_time_now = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    def seed_worker(worker_id):
        worker_seed = torch.initial_seed() % 2 ** 32
        np.random.seed(worker_seed)
        random.seed(worker_seed)

    if args.dataset == 'Multiviewx':
        dataset = MultiviewX(os.path.expanduser(f'Data/{args.dataset}'))
    elif args.dataset == 'MVPerception':
        dataset = MVPerception(os.path.expanduser(f'Data/{args.dataset}'))
    elif args.dataset == 'Wildtrack':
        dataset = Wildtrack(os.path.expanduser(f'Data/{args.dataset}'))
    train_set = frameDataset(dataset, train=True, world_reduce=args.world_reduce,
                             img_reduce=args.img_reduce, world_kernel_size=args.world_kernel_size,
                             img_kernel_size=args.img_kernel_size, semi_supervised=args.semi_supervised,
                             dropout=args.dropcam, augmentation=args.augmentation)
    test_set = frameDataset(dataset, train=False, world_reduce=args.world_reduce,
                            img_reduce=args.img_reduce, world_kernel_size=args.world_kernel_size,
                            img_kernel_size=args.img_kernel_size)

    train_loader = DataLoader(train_set, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
                              pin_memory=True, worker_init_fn=seed_worker)
    test_loader = DataLoader(test_set, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers,
                             pin_memory=True, worker_init_fn=seed_worker)

    model = MVtr(train_set, args.z, args.arch, world_feat_arch=args.world_feat, bottleneck_dim=args.bottleneck_dim,
                 outfeat_dim=args.outfeat_dim, droupout=args.dropout).cuda()

    # model.load_state_dict(torch.load(f'logs\\MultiviewDetectorMultiviewX.pth'))
    # model.load_state_dict(torch.load(f'logs\\MultiviewDetectorWildetrack.pth'))
    # model.load_state_dict(torch.load(f'logs\\MultiviewDetectorMVPerception.pth'))

    param_dicts = [{"params": [p for n, p in model.named_parameters() if 'base' not in n and p.requires_grad], },
                   {"params": [p for n, p in model.named_parameters() if 'base' in n and p.requires_grad],
                    "lr": args.lr * args.base_lr_ratio, }, ]

    optimizer = optim.Adam(param_dicts, lr=args.lr, weight_decay=args.weight_decay)
    scaler = GradScaler()
    scheduler = torch.optim.lr_scheduler.OneCycleLR(optimizer, max_lr=args.lr, steps_per_epoch=len(train_loader),
                                                    epochs=args.epochs)

    trainer = PerspectiveTrainer(model, args.cls_thres, args.alpha, args.use_mse, args.id_ratio, args.world_reduce,
                                 args.world_kernel_size)

    logdir = f'logs/{args.dataset}-{date_time_now}/test'
    os.makedirs(logdir, exist_ok=True)

    res_fpath = os.path.join(f'logs', 'test.txt')
    sys.stdout = Logger(os.path.join(logdir, f'output.log'))

    test_loss, moda = trainer.test(0, test_loader, res_fpath)
    print(test_loss)
    eval(args.dataset)

    for epoch in tqdm.tqdm(range(1, args.epochs + 1)):
        print('Training...')
        train_loss = trainer.train(epoch, train_loader, train_set, optimizer, scaler, scheduler)
        print(train_loss)
        torch.save(model.state_dict(), os.path.join(logdir, f'MultiviewDetector{epoch}.pth'))
        print('Testing...')
        test_loss, moda = trainer.test(epoch, test_loader, res_fpath)
        print(test_loss)
        eval(args.dataset)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Multiview detector')
    parser.add_argument('--reID', action='store_true')
    parser.add_argument('--semi_supervised', type=float, default=0)
    parser.add_argument('--id_ratio', type=float, default=0)
    parser.add_argument('--cls_thres', type=float, default=0.5)
    parser.add_argument('--alpha', type=float, default=1.0, help='ratio for per view loss')
    parser.add_argument('--use_mse', type=str2bool, default=False)
    parser.add_argument('--arch', type=str, default='resnet18', choices=['vgg11', 'resnet18', 'mobilenet'])
    parser.add_argument('--z', type=list, default=[0])
    parser.add_argument('-d', '--dataset', type=str, default='Wildtrack', choices=['Wildtrack', 'Multiviewx', 'MVPerception'])
    parser.add_argument('-j', '--num_workers', type=int, default=0)
    parser.add_argument('-b', '--batch_size', type=int, default=1, help='input batch size for training')
    parser.add_argument('--dropout', type=float, default=0.0)
    parser.add_argument('--dropcam', type=float, default=0.0)
    parser.add_argument('--epochs', type=int, default=20, help='number of epochs to train')
    parser.add_argument('--lr', type=float, default=5e-4, help='learning rate')
    parser.add_argument('--base_lr_ratio', type=float, default=0.1)
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--resume', type=str, default=None)
    parser.add_argument('--visualize', action='store_true')
    parser.add_argument('--seed', type=int, default=2023, help='random seed')
    parser.add_argument('--deterministic', type=str2bool, default=False)
    parser.add_argument('--augmentation', type=str2bool, default=True)

    parser.add_argument('--world_feat', type=str, default='deform_trans',
                        choices=['trans', 'deform_trans', 'aio'])
    parser.add_argument('--bottleneck_dim', type=int, default=128)
    parser.add_argument('--outfeat_dim', type=int, default=0)
    parser.add_argument('--world_reduce', type=int, default=4)
    parser.add_argument('--world_kernel_size', type=int, default=10)
    parser.add_argument('--img_reduce', type=int, default=12)
    parser.add_argument('--img_kernel_size', type=int, default=10)

    args = parser.parse_args()

    print(torch.cuda.is_available(), torch.__version__)

    main(args)
