import os

import pandas as pd

os.environ['OMP_NUM_THREADS'] = '1'
from PIL import Image, ImageDraw
import tqdm
import cv2
import hashlib
import matplotlib.pyplot as plt
import numpy as np
import torch
import torchvision.transforms as T
import torch.nn.functional as F
from multiview_detector.datasets import frameDataset, Wildtrack, MultiviewX, MVPerception
from multiview_detector.utils.image_utils import img_color_denormalize


def _traget_transform(target, kernel):
    with torch.no_grad():
        target = F.conv2d(target, kernel.float().to(target.device), padding=int((kernel.shape[-1] - 1) / 2))
    return target


def id_to_color(id):
    hash = hashlib.sha256()
    hash.update(str(id).encode('utf-8'))
    hex_value = hash.hexdigest()
    hex_value = hex_value[:8]
    return tuple(int(hex_value[i:i + 2], 16) for i in (0, 2, 4))


def interpolate_colors(color1, color2, ratio):
    return tuple(int(color1[i] * (1 - ratio) + color2[i] * ratio) for i in range(3))


def draw_interpolate_pt(img, ptall, start_color, end_color):
    lp = len(ptall)
    if lp > 1:
        for i in range(lp - 1):
            draw_gradient_line(img, ptall[i], ptall[i + 1],
                               interpolate_colors(start_color, end_color, 1 - i / lp),
                               interpolate_colors(start_color, end_color, 1 - (i + 1) / lp))
    if lp == 1:
        cv2.circle(img, (ptall[0][0], ptall[0][1]), 1, start_color, -1)


def draw_gradient_line(img, pt1, pt2, start_color, end_color):
    distance = int(np.hypot(pt2[0] - pt1[0], pt2[1] - pt1[1]))

    for i in range(distance):
        # Calculate the points and colors
        points = [(int(pt1[0] * (1 - i / distance) + pt2[0] * i / distance),
                   int(pt1[1] * (1 - i / distance) + pt2[1] * i / distance))
                  for i in range(distance)]
        colors = [interpolate_colors(start_color, end_color, i / distance)
                  for i in range(distance)]

        # Draw the points
        [cv2.circle(img, point, 2, color, 2) for point, color in zip(points, colors)]


def main(dataset_name='wildtrack'):
    if dataset_name == 'multiviewx':
        result_fpath = 'logs/test.txt'
        dataset = frameDataset(MultiviewX(os.path.expanduser('Data/MultiviewX')), False, )
    elif dataset_name == 'MVPerception':
        result_fpath = 'logs/test.txt'
        dataset = frameDataset(MVPerception(os.path.expanduser('Data/MVPerception')), False, )
    elif dataset_name == 'wildtrack':
        result_fpath = 'logs/test.txt'
        dataset = frameDataset(Wildtrack(os.path.expanduser('Data/Wildtrack')), False, )
    else:
        raise Exception('must choose from [wildtrack, multiviewx, mvperception]')
    bbox_by_pos_cam = dataset.base.read_pom()
    results = np.loadtxt(result_fpath)
    denorm = img_color_denormalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    end_color = (123, 123, 123)
    reshape_transform = T.Resize(dataset.img_shape)
    length = 15
    if dataset_name == 'multiviewx' or 'MVPerception':
        num_frames = int(results[-1, 0] - results[0, 0] + 1)
    elif dataset_name == 'wildtrack':
        num_frames = int((results[-1, 0] - results[0, 0]) / 5) + 1
    views_dataframes = {}

    for index in range(num_frames):
        imgs, map_gt, imgs_gt, affine_mats, frame, _, _ = dataset.__getitem__(index)
        imgs = reshape_transform(denorm(imgs))
        res_id_map_grid = results[results[:, 0] == frame, 1:]
        res_map_id = res_id_map_grid[:, 0]
        if dataset_name == 'multiviewx' or 'MVPerception':
            res_map_grid = res_id_map_grid[:, 1:]
        elif dataset_name == 'wildtrack':
            res_map_grid = res_id_map_grid[:, 1:][:, [1, 0]]

        res_posID = dataset.base.get_pos_from_worldgrid(res_map_grid.transpose())

        for cam in range(dataset.num_cam):
            img = (imgs[cam].cpu().numpy().transpose([1, 2, 0]) * 255).astype('uint8').copy()
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            disappeared_ids = set(results[results[:, 0] == (frame - 5), 1])

            for i, posID in enumerate(res_posID):
                bbox = bbox_by_pos_cam[posID][cam]
                pid = res_map_id[i]
                if bbox is not None:
                    track_idx = np.where(results[:, 1] == pid)[0]
                    track = results[track_idx]
                    track = track[track[:, 0] <= frame, 2:] if index < length else track[track[:, 0] <= frame, 2:][
                                                                                   -length:, :]
                    if dataset_name == 'wildtrack':
                        track = track[:, [1, 0]]
                    if res_map_id[i] in disappeared_ids:
                        disappeared_ids.remove(res_map_id[i])
                    idc = id_to_color(pid)
                    x1, y1, x2, y2 = bbox[:4]
                    cropped_img = img[y1:y2, x1:x2]
                    save_path = f'logs/{dataset_name}/an/viewNum_{cam}/ID_{str(int(pid))}'
                    os.makedirs(save_path, exist_ok=True)
                    cv2.imwrite(f'{save_path}/{index}.jpg', cropped_img)
                    cv2.rectangle(img, tuple(bbox[:2]), tuple(bbox[2:]), idc, 2)
                    cv2.putText(img, str(int(pid)), tuple(bbox[:2]), cv2.FONT_HERSHEY_SIMPLEX, 1, idc, 3)
                    track = dataset.base.get_pos_from_worldgrid(track.transpose())
                    p_all = []
                    for t in track:
                        b = bbox_by_pos_cam[t][cam]
                        if b is not None:
                            p = (int((b[2] - b[0]) / 2) + b[0], b[3])
                            p_all.append(p)
                            w = b[2] - b[0]
                            h = b[3] - b[1]
                            row = {'Frame': frame, 'PersonID': pid, 'x': b[0], 'y': b[1], 'w': w,
                                   'h': h, 'oc': 1, 'class': -1, '1': -1, '0': -1}
                            if cam not in views_dataframes:
                                views_dataframes[cam] = pd.DataFrame([row])
                            else:
                                mask = (views_dataframes[cam]['Frame'] == frame) & (views_dataframes[cam]['PersonID']
                                                                                    == pid)
                                views_dataframes[cam] = views_dataframes[cam][~mask]
                                views_dataframes[cam] = views_dataframes[cam].append(row, ignore_index=True)
                    draw_interpolate_pt(img, p_all, idc, end_color)
            cv2.putText(img, 'C' + str((cam + 1)), (50, 1020), cv2.FONT_HERSHEY_SIMPLEX, 4, (32, 230, 248), 12)

            dirpath = f"imgs/cam{cam + 1}"

            if not os.path.exists(dirpath):
                os.makedirs(dirpath)

            # Save the image
            cv2.imwrite(f'{dirpath}/{frame}.png', img)


if __name__ == '__main__':
    main('wildtrack')
    # main('multiviewx')
    # main('MVPerception')

