import numpy as np
import torch
from cv2 import KalmanFilter
from torch import nn

from Hungarianmatcher import HungarianMatcher

def delet_element(tensor, value_to_remove):
    mask = tensor != value_to_remove
    return tensor[mask]


class Kalman_Filtering_2D:

    def __init__(self, n_points):
        self.n_points = n_points

    def initialize(self):

        n_states = self.n_points * 4
        n_measures = self.n_points * 2
        self.kalman = KalmanFilter(n_states, n_measures)
        kalman = self.kalman
        kalman.transitionMatrix = np.eye(n_states, dtype=np.float32)
        kalman.measurementNoiseCov = np.eye(n_measures, dtype=np.float32)*0.0005

        kalman.measurementMatrix = np.zeros((n_measures, n_states), np.float32)
        dt = 1

        self.Measurement_array = []
        self.dt_array = []

        for i in range(0, n_states, 4):
            self.Measurement_array.append(i)
            self.Measurement_array.append(i+1)

        for i in range(0, n_states):
            if i not in self.Measurement_array:
                self.dt_array.append(i)

        for i, j in zip(self.Measurement_array, self.dt_array):
            kalman.transitionMatrix[i, j] = dt

        for i in range(0, n_measures):
            kalman.measurementMatrix[i, self.Measurement_array[i]] = 1

    def predict(self, points):

        pred = []
        input_points = np.float32(np.ndarray.flatten(points))
        # Correction Step
        self.kalman.correct(input_points)
        # Prediction step
        tp = self.kalman.predict()

        for i in self.Measurement_array:
            pred.append((tp[i]))

        return pred


class Tracker(nn.Module):
    def __init__(self):
        super().__init__()
        self.matcher = HungarianMatcher()
        self.unmatched_id = torch.tensor([])
        self.patience_window = torch.tensor([])
        self.l_all = 0

    def match_track(self, p_pos, pos, prev_track_id, res_list, thres=50):
        # match
        out_ind, target_ind = self.matcher(p_pos, pos)
        track_new_ID = torch.zeros_like(pos[:, 1]).long() - 1
        track_new_ID[target_ind] = prev_track_id[out_ind]

        # refine
        unmatched_id = torch.tensor([val for i, val in enumerate(prev_track_id) if i not in out_ind])
        self.patience_window = torch.cat([self.patience_window, self.unmatched_id], dim=0)
        if len(unmatched_id) > 0:
            self.unmatched_id = torch.unique(torch.cat([self.unmatched_id, unmatched_id], dim=0))
        for id in self.unmatched_id:
            if len(torch.nonzero(self.patience_window == id, as_tuple=False)) > 20:
                self.patience_window = delet_element(self.patience_window, id)
                self.unmatched_id = delet_element(self.unmatched_id, id)
        unmatched_pos = pos[[i for i in range(len(pos)) if i not in out_ind]]
        uni_unmatched_id = self.unmatched_id

        pred_unmatched_id_pos = {}
        for unid in uni_unmatched_id:
            observations = np.array([[row[2].item(), row[3].item()] for res in res_list for row in res if row[1] == unid])
            if observations.shape[0] > 1:
                kf = Kalman_Filtering_2D(1)
                kf.initialize()
                for ob in observations:
                    pred_state = kf.predict(ob)
            elif observations.shape[0] == 1:
                pred_state = observations[0]
            pred_unmatched_id_pos[unid] = pred_state

        for k in pred_unmatched_id_pos.keys():
            un = pred_unmatched_id_pos[k]
            for p in unmatched_pos:
                d = (torch.tensor(un[0]) - p[0]) ** 2 + (torch.tensor(un[1]) - p[1]) ** 2
                if d < thres:
                    re_ind = (pos == p)[:, 0].nonzero(as_tuple=False).squeeze()
                    track_new_ID[re_ind] = k

        # creat new
        count = len((track_new_ID == -1).nonzero(as_tuple=False))
        track_new_ID[track_new_ID == -1] = Tracker.creat_new_track(track_new_ID[track_new_ID == -1], self.l_all)
        self.l_all += count
        return track_new_ID, pred_unmatched_id_pos, target_ind, out_ind

    def init_track(self, pos):
        l_new = len(pos)
        init_track= torch.tensor(range(0, 0 + l_new)).long()
        self.l_all += l_new
        return init_track


    @staticmethod
    def creat_new_track(pos, count=0):
        l_new = len(pos)
        track_new_ID = torch.tensor(range(count, count + l_new)).long()
        return track_new_ID

    def end_tracking(self):
        self.l_all = 0
