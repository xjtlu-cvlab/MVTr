# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
"""
Modules to compute the matching cost and solve the corresponding LSAP.
"""
import math

import matplotlib.pyplot as plt
import numpy as np
import torch
from scipy.optimize import linear_sum_assignment
from torch import nn
import torch.nn.functional as F


class HungarianMatcher(nn.Module):

    def __init__(self, cost_threshold=10000):
        super().__init__()
        self.cost_threshold = cost_threshold

    @torch.no_grad()
    def forward(self, outputs, targets, cls_thres=50):
        out_bbox = outputs
        tgt_bbox = targets

        cost_bbox = torch.cdist(out_bbox, tgt_bbox, p=2)

        cost_bbox[cost_bbox > cls_thres] = self.cost_threshold

        indices = linear_sum_assignment(cost_bbox)

        row_indices, col_indices = indices

        # Apply mask to row and column indices so that we only preserve pairs with distance < threshold
        mask = cost_bbox[row_indices, col_indices] < cls_thres
        row_indices = row_indices[mask]
        col_indices = col_indices[mask]

        return row_indices, col_indices

