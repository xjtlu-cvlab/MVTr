import os

import motmetrics as mm
import pandas as pd
from multiview_detector.evaluation.evaluate import evaluate


def main(dataset='wildtrack'):
    metrics = list(mm.metrics.motchallenge_metrics)
    gt_original_file = f"Data\\{dataset}\\mot_gt\\gt.txt"
    gt_file = f"Data\\{dataset}\\mot_gt\\gt_test.txt"
    ts_file = f"logs\\test.txt"
    filter_rows(gt_original_file, ts_file, gt_file)

    distth = 50
    gt = load_MVMOT(gt_file)
    ts = load_MVMOT(ts_file)
    name = os.path.splitext(os.path.basename(ts_file))[0]
    distfields = ['X', 'Y']

    acc = mm.utils.compare_to_groundtruth(gt, ts, 'EUC', distfields, distth)
    output_file = 'acc_events.txt'

    with open(output_file, 'w') as file:
        file.write(acc.events.to_string())

    mh = mm.metrics.create()
    summary = mh.compute(acc, metrics=metrics, name=name)
    summary['motp'] = 1 - summary['motp'] / distth
    print(mm.io.render_summary(summary, formatters=mh.formatters, namemap=mm.io.motchallenge_metric_names))


def load_MVMOT(fname):
    sep = r'\s+|\t+|,'
    df = pd.read_csv(
        fname,
        sep=sep,
        index_col=[0, 1],
        skipinitialspace=True,
        header=None,
        names=['FrameId', 'Id', 'X', 'Y'],
        engine='python'
    )

    # Account for matlab convention.
    df[['X', 'Y']] -= (1, 1)

    # Remove all rows without sufficient confidence
    return df


def filter_rows(gt_path, test_path, gt_test_path):
    with open(test_path, 'r') as file:
        test_frame_ids = [int(line.strip().split()[0]) for line in file]

    filtered_rows = []
    with open(gt_path, 'r') as file:
        for line in file:
            frame_id = int(line.split(' ')[0])
            if frame_id >= test_frame_ids[0]:
                filtered_rows.append(line)

    with open(gt_test_path, 'w') as file:
        file.writelines(filtered_rows)


if __name__ == '__main__':
    main('wildtrack')
