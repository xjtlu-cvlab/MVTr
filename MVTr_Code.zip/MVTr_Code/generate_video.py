import cv2
import os

import numpy as np

from multiview_detector.datasets import frameDataset, Wildtrack, MultiviewX


def aoi(dataset):
    if dataset == 'wildtrack':
        c1 = [((1190, 182), (5, 403)), ((1881, 228), (1747, 1079)), None, ((1190, 182), (1881, 228))]
        c2 = [None, ((1468, 77),(4, 354)), ((1918, 85), (1468, 77)), None]
        c3 = [((1916, 369), (864, 202)), ((73, 273), (170, 1079)), ((864, 202), (73, 273)), None]
        c4 = [((1916, 258), (2, 449)), None, None, None]
        c5 = [None, ((1915, 402), (4, 436)), None, None]
        c6 = [((27, 204), (1, 279)),  ((1913, 450), (653, 193)), None, ((653, 193), (27, 204))]
        c7 = [((4, 245), (1917, 162)), ((1836, 1079), (1914, 1033)), None, None]
        return [c1, c2, c3, c4, c5, c6, c7]
    elif dataset == 'multiviewx':
        c1 = [((571, 429), (0, 642)), None, ((1917, 429), (571, 429)), None]
        c2 = [None, ((680, 383), (1, 444)), None, ((680, 383), (1918, 492))]
        c3 = [((1439, 401), (1918, 463)), None, None, ((0, 475), (1439, 401))]
        c4 = [((0, 416), (448, 375)), ((1632, 934), (1383, 415)), ((1383, 415), (448, 375)), ((1632, 934), (0, 573))]
        c5 = [((1097, 381), (1890, 415)), None, ((1918, 431), (1890, 415)), ((1, 650), (1097, 381))]
        c6 = [None, ((1101, 381), (469, 391)), ((469, 391), (0, 540)), ((1101, 381), (1918, 614))]
        return [c1, c2, c3, c4, c5, c6]
    elif dataset == 'mvperception':
        c1 = [((676, 564), (1246, 564)), None, ((0, 724), (676, 564)), ((1246, 564), (1917, 725))]
        c2 = [((1117, 558), (1917, 614)), None, ((0, 635), (1117, 558)), ((1553, 1079), (1918, 649))]
        c3 = [None, ((0, 619), (686, 558)), ((686, 558), (1918, 624)), ((72, 1079), (1, 973))]
        c4 = [None, ((1266, 561), (649, 561)), ((1266, 561), (1918, 716)), ((649, 561), (1, 717))]
        c5 = [None, ((1918, 619), (1232, 557)), ((1917, 1002), (1869, 1079)), ((1232, 557), (1, 624))]
        c6 = [((0, 614), (803, 558)), None, ((331, 1079), (0, 650)), ((1917, 635), (803, 558))]
        return [c1, c2, c3, c4, c5, c6]
    else:
        raise ValueError('Cannot read the dataset')


def draw_FOV_line(img, bbox_by_pos_cam, cam, ps, col=(0, 0, 255)):
    p_min, p_max = min(ps), max(ps)
    b_min = bbox_by_pos_cam[p_min][cam]
    b_max = bbox_by_pos_cam[p_max][cam]
    t_min = (int((b_min[2] - b_min[0]) / 2) + b_min[0], b_min[3])
    t_max = (int((b_max[2] - b_max[0]) / 2) + b_max[0], b_max[3])
    print(t_min, t_max)
    cv2.line(img, t_min, t_max, col, 2)


def generate_video(dataset='wildtrack'):
    global input_folder, image_files, fpath, camnum

    if dataset == 'wildtrack':
        fpath = f"imgswildtrack//"
        camnum = 7
    elif dataset == 'multiviewx':
        fpath = f"imgsmultiviewx//"
        camnum = 6
    elif dataset == 'mvperception':
        fpath = f"imgsmvperception//"
        camnum = 6
    else:
        raise ValueError('Cannot read the dataset')
    input_folder = os.path.join(fpath, 'cam1')
    image_files = sorted([f for f in os.listdir(input_folder) if f.endswith('.png')])

    output_file = os.path.join(fpath, f'{dataset}video.avi')

    first_image = cv2.imread(os.path.join(input_folder, image_files[0]))
    height, width, _ = first_image.shape

    new_width = int(width / 4)
    new_height = int(height / 4)

    gap = 15
    num_rows = 3
    num_cols = 3
    blank_width = (new_width + gap) * num_cols
    blank_height = (new_height + gap) * num_rows + 50

    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    video_writer = cv2.VideoWriter(output_file, fourcc, 2.0, (blank_width, blank_height))

    for image_file in image_files:
        blank_image = np.ones((blank_height, blank_width, 3), dtype=np.uint8) * 255
        if dataset == 'wildtrack':
            start_x = 2 * (new_width + gap)
            end_x = start_x + new_width
            start_y = 2 * (new_height + gap)
            end_y = start_y + new_height
        elif dataset == 'multiviewx':
            start_x = 1 * (new_width + gap)
            end_x = start_x + new_width
            start_y = 2 * (new_height + gap)
            end_y = start_y + new_height
        elif dataset == 'mvperception':
            start_x = 1 * (new_width + gap)
            end_x = start_x + new_width
            start_y = 2 * (new_height + gap)
            end_y = start_y + new_height
        else:
            raise ValueError('Cannot read the dataset')

        FOVimg = cv2.imread(os.path.join(fpath, f'FOV.png'))
        blank_image[start_y:end_y, start_x:end_x] = cv2.resize(FOVimg, (new_width, new_height))
        for j in range(1, camnum + 2):
            input_folder = (os.path.join(fpath, f'trajectory') if j == camnum + 1 else os.path.join(fpath, f'cam{j}'))
            image_path = os.path.join(input_folder, image_file)
            image = cv2.imread(image_path)
            if j < camnum + 1:
                lines = aoi(dataset)
                line = lines[j-1]
                for p in line:
                    if p is not None:
                        cv2.line(image, p[0], p[1], (0, 0, 255), 3)

            resized_image = cv2.resize(image, (new_width, new_height))
            row = (j - 1) // num_cols
            col = (j - 1) % num_cols
            start_x = col * (new_width + gap)
            end_x = start_x + new_width
            start_y = row * (new_height + gap)
            end_y = start_y + new_height
            blank_image[start_y:end_y, start_x:end_x] = resized_image
        cv2.putText(blank_image, 'frame:' + str(image_file.split('.')[0]), (30, blank_height - 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)
        video_writer.write(blank_image)

    video_writer.release()


if __name__ == '__main__':
    generate_video('mvperception')