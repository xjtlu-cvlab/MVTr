import os

import cv2

dir = 'logs\wildtrack\\an\\viewNum_0\ID_2'

image_files = [f for f in os.listdir(dir) if f.endswith('.jpg')]
image_files = sorted(image_files, key=lambda x: int(''.join(filter(str.isdigit, x))))

fourcc = cv2.VideoWriter_fourcc(*'mp4v')

video_out = None

for image_file in image_files:
    image_path = os.path.join(dir, image_file)
    img = cv2.imread(image_path)

    if video_out is None:
        height, width, _ = img.shape
        video_out = cv2.VideoWriter(f'{dir}/output_video.mp4', fourcc, 10.0, (width, height))

    img_resized = cv2.resize(img, (width, height))

    video_out.write(img_resized)

video_out.release()