function imgExt = getImgExt(seqFolder)
% return image extension including the dot
% e.g.   '.jpg'

imgExt = '.jpg';




