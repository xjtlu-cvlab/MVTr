import torch
import torch.nn as nn

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(LSTMModel, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.conv = nn.Conv1d(hidden_size, output_size, kernel_size=1)

    def forward(self, x):
        x = x.permute(0, 2, 1)  # 调整输入的维度顺序，使其符合卷积层的要求
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = out.permute(0, 2, 1)  # 调整输出的维度顺序，与输入特征图相同
        out = self.conv(out)
        return out

# 创建LSTM模型实例
input_size = 2000  # 输入特征图的通道数
hidden_size = 64  # LSTM隐藏状态的维度
num_layers = 2  # LSTM层数
output_size = 2000  # 输出特征图的通道数
lstm_model = LSTMModel(input_size, hidden_size, num_layers, output_size).to('cuda')

# 构造随机输入样本
input_tensor = torch.randn(256, 2000, input_size).to('cuda')

# 前向传播
output_tensor = lstm_model(input_tensor)
print(output_tensor.shape)  # 输出特征图的尺寸
